# Azure Adventure Day
This repo contains
- Instructions how to [set up your infrastructure](setup-infra-gameengine.md)
- Source Code for your bot
