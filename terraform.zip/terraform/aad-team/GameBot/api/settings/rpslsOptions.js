const RPSLSChoices = [
    'rock',
    'paper',
    'scissors',
    'snap',
    'metal',
];

const RPSLSStrategies = {
    RANDOM: 'random',
    ROCK: 'rock',
    PAPER: 'paper',
    SCISSORS: 'scissors',
    SNAP: 'snap',
    METAL: 'metal',
}

module.exports = {
    RPSLSChoices,
    RPSLSStrategies,
}