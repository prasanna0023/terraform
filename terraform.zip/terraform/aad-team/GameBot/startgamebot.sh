ssh-keygen -A
crond
/usr/sbin/sshd -E out.txt -p 50000
npm run start